#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cassert>
#include <cmath>

#include <pthread.h>
#include <inttypes.h>
#include <unistd.h>

// STL
#include <string>
#include <vector>
#include <list>
#include <map>

// QT
#include <QtGui>

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cassert>
#include <cmath>

#include <pthread.h>
#include <inttypes.h>
#include <unistd.h>

// STL
#include <string>
#include <vector>
#include <list>
#include <map>

// QT
#include <QLibrary>
#include <QDir>


